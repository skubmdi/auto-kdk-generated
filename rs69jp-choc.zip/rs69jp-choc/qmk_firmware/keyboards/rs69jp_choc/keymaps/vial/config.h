#pragma once
#define VIAL_KEYBOARD_UID {0x85, 0xbc, 0x30, 0xda, 0xae, 0x75, 0x4b, 0xa7}
#define VIAL_TAP_DANCE_ENTRIES 8
#define VIAL_COMBO_ENTRIES 8
#define PICO_FLASH_SIZE_BYTES (1 * 1024 * 1024)